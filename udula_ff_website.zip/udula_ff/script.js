// EDIT PACKAGES AND PRICES HERE (prices are sample LKR amounts)
const packages = [
  {diamonds:100, price:350},
  {diamonds:310, price:950, popular:true},
  {diamonds:520, price:1550},
  {diamonds:1060, price:3100},
  {diamonds:2180, price:6200},
  {diamonds:5600, price:15500}
];
// Add your WhatsApp number in international format without + or spaces. Example: 94771234567
const WHATSAPP_NUMBER = "";
const grid=document.getElementById('packageGrid');const modal=document.getElementById('modal');let chosen=null;
packages.forEach(pkg=>{const card=document.createElement('article');card.className='package';card.innerHTML=`${pkg.popular?'<span class="popular">POPULAR</span>':''}<div class="pkg-icon">💎</div><h3>${pkg.diamonds.toLocaleString()} Diamonds</h3><p class="caption">Free Fire top-up package</p><p class="price">LKR ${pkg.price.toLocaleString()}</p><button class="btn primary" type="button">BUY NOW ↗</button>`;card.querySelector('button').addEventListener('click',()=>openOrder(pkg,card));grid.appendChild(card)});
function openOrder(pkg,card){chosen=pkg;document.querySelectorAll('.package').forEach(c=>c.classList.remove('selected'));card.classList.add('selected');document.getElementById('selectedInfo').textContent=`💎 ${pkg.diamonds.toLocaleString()} Diamonds — LKR ${pkg.price.toLocaleString()}`;document.getElementById('error').textContent='';document.getElementById('uid').value='';document.getElementById('nickname').value='';modal.classList.add('open');document.getElementById('uid').focus()}
document.getElementById('closeModal').addEventListener('click',()=>modal.classList.remove('open'));modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open')});
document.getElementById('sendOrder').addEventListener('click',()=>{const uid=document.getElementById('uid').value.trim(),nick=document.getElementById('nickname').value.trim();const error=document.getElementById('error');if(!uid){error.textContent='Please enter your Player UID.';return}if(!chosen)return;if(!WHATSAPP_NUMBER){error.textContent='Store WhatsApp number is not configured yet. Edit WHATSAPP_NUMBER in script.js.';return}const text=`Udula FF Order%0APlayer UID: ${encodeURIComponent(uid)}%0ANickname: ${encodeURIComponent(nick||'Not provided')}%0APackage: ${chosen.diamonds} Diamonds%0APrice: LKR ${chosen.price.toLocaleString()}`;window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${text}`,'_blank');modal.classList.remove('open')});
document.getElementById('menuBtn').addEventListener('click',()=>document.getElementById('nav').classList.toggle('open'));document.querySelectorAll('#nav a').forEach(a=>a.addEventListener('click',()=>document.getElementById('nav').classList.remove('open')));document.getElementById('year').textContent=new Date().getFullYear();
